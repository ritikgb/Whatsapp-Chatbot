from flask import Flask, request
import requests
from twilio.twiml.messaging_response import MessagingResponse
from twilio.rest import Client
#sid='ACdb3eb660258bd08dfc6da57f1300e3cd'
#authToken='9323ef954073cd1c7b7af93a9ab78e24'
#client=Client(sid,authToken)

app = Flask(__name__)

@app.route('/mybot', methods=['POST'])
def bot():
    user_msg = request.values.get('Body','').lower()
    bot_resp = MessagingResponse()
    msg = bot_resp.message()
    if 'hello' in user_msg:
        msg.body("Hi there! How may I help you?")
    elif 'machine learning' in user_msg:
        msg.body("Machine")
        msg.body('you can learn')
    elif 'image processing' in user_msg:
        msg.body("Img")
    elif 'natural language' in user_msg:
        msg.body("Hi")
    elif 'quote' in user_msg:
        r = request.get('https://api.quotable.io/random')
        if r.status_code == 200:
            data = r.json()
            quote = f'{data["content"]} ({data["author"]})'
        else:
            quote ='I could not retriveve sorry'
        msg.body(quote)
    elif 'cat' in user_msg:
        msg.media('hdhd')
    else:
        msg.body("sorry")
    return str(bot_resp)

if __name__ == '__main__':
    app.run(debug=True)